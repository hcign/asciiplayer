package cmd

const (
	// Version version
	Version = "1.0"
	// HomePage homepage
	HomePage = "https://pornhub.com/"
	// Author author
	Author = "prmze"
	// ShortTitle shortTitle
	ShortTitle = "giftotfx/" + Version + "1.0"

	// Title title
	Title = `
╔═╗╦╔═╗  ╔╦╗╔═╗  ╔╦╗╔═╗═╗ ╦
║ ╦║╠╣    ║ ║ ║   ║ ╠╣ ╔╩╦╝
╚═╝╩╚     ╩ ╚═╝   ╩ ╚  ╩ ╚═`
	// SummaryTitle summary title
	SummaryTitle = Title + "\nVersion  : " + Version + "\nMade By: " + Author
)
