package util

import "testing"

func TestIsGif(t *testing.T) {
	IsGif("testdata/suolong.gif")
}
